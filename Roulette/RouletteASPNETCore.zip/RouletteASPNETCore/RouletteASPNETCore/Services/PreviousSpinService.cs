﻿using RouletteASPNETCore.Models;

namespace RouletteASPNETCore.Services
{
    public class PreviousSpinService : IPreviousSpinService
    {
        public int SpinResult { get; set; }
        public List<int> SpinResultArray = new List<int>();

        public PreviousSpinService(int spinResult)
        {
            SpinResult = spinResult;
        }

        // Add spin result to top of array
        public void AddSpinResult()
        {
            SpinResultArray.Insert(0, SpinResult);
        }

        // Return previous spin history
        public List<int> GetSpinHistory()
        {
            return SpinResultArray;
        }

        List<WheelNumber> IPreviousSpinService.GetSpinHistory()
        {
            throw new NotImplementedException();
        }
    }
}
