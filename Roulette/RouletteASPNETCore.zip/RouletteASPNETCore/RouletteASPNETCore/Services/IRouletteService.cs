﻿using RouletteASPNETCore.Models;

namespace RouletteASPNETCore.Services
{
    public interface IRouletteService
    {
        //List<WheelNumber> GetAllWheelNumbers();
        WheelNumber GetWheelNumber(WheelNumber wheelNumber);
        //List<WheelNumber> AddWheelNumber(WheelNumber newWheelNumber);
        
        
        //List<Bet> PlaceBet();
        //Payout
        //ShowPreviousSpins

    }
}
