﻿using RouletteASPNETCore.Models;

namespace RouletteASPNETCore.Services
{
    public interface IPreviousSpinService
    {
        // Add spin result to top of array
        public void AddSpinResult();

        // Return previous spin history
        public List<WheelNumber> GetSpinHistory();
        
       



    }
}
