﻿using RouletteASPNETCore.Models;

namespace RouletteASPNETCore.Services
{
    public class RouletteService : IRouletteService
    {
        //public static List<WheelNumber> wheelNumberHistory = new List<WheelNumber>
        //{
        //    new WheelNumber{ Number = 99, Color = WheelColor.NoColor }
        //};

        //public void AddWheelNumber()
        //{

        //}

        //public List<WheelNumber> GetAllWheelNumbers()
        //{
        //    return wheelNumberHistory;
        //}

        public WheelNumber GetWheelNumber(WheelNumber wheelNumber)
        {
            Random random = new Random();
            wheelNumber.Number = random.Next(0, 37);

            if (wheelNumber.Number == 0)
            {
                wheelNumber.Color = WheelColor.Green;
            }
            else
            {
                wheelNumber.Color = wheelNumber.Number % 2 == 0 ?
                    WheelColor.Red : WheelColor.Black;
            }

            //if (wheelNumbers[0].Number == 99) { wheelNumbers.RemoveAt(0); }

            //wheelNumberHistory.Add(wheelNumber); //add new number to top of list

            return wheelNumber;
        }
    }
}
