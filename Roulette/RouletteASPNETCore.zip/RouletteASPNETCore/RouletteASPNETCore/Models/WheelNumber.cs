﻿namespace RouletteASPNETCore.Models
{
    public class WheelNumber
    {
        public int Number { get; set; }
        public WheelColor Color { get; set; } = WheelColor.NoColor;
    }
}
