﻿using System.Text.Json.Serialization;

namespace RouletteASPNETCore.Models
{
    [JsonConverter(typeof(JsonStringEnumConverter))]
    public enum BetStatus
    {
        Lose,
        Pending,
        Win

    }
}
