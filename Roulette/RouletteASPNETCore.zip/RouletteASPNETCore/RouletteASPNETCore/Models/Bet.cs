﻿namespace RouletteASPNETCore.Models
{
    public class Bet
    {
        public int Id { get; set; }
        public int Number { get; set; }
        public double AmountPlaced { get; set; } = 5;
        public double Odds { get; set; } = 35;
        public bool Outcome { get; set; } = false;
        public BetStatus BetStatus { get; set; } = BetStatus.Pending;
        public double Winnings { get; set; } = 0;
        DateTime CreatedDate => DateTime.Now;
    }
}
