﻿using System.Text.Json.Serialization;

namespace RouletteASPNETCore.Models
{
    [JsonConverter(typeof(JsonStringEnumConverter))]
    public enum WheelColor
    {
        Black,
        Green,
        Red,
        NoColor
    }
}
