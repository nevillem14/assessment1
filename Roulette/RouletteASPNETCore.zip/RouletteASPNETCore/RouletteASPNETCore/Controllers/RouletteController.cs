using Microsoft.AspNetCore.Mvc;
using RouletteASPNETCore.Models;
using RouletteASPNETCore.Services;

namespace RouletteASPNETCore.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class RouletteController : ControllerBase
    {
        private readonly IRouletteService _rouletteService;

        public RouletteController(IRouletteService rouletteService)
        {
            _rouletteService = rouletteService;

        }

        private static readonly WheelNumber wheelNumber = new WheelNumber();
        

        [HttpGet("SpinWheel")]
        public ActionResult<WheelNumber> SpinWheel()
        {

            return Ok(_rouletteService.GetWheelNumber(wheelNumber));

        }

        //[HttpGet("GetHistory")]
        //public ActionResult<List<WheelNumber>> GetAll()
        //{
        //    return Ok(_rouletteService.GetAllWheelNumbers());
        //}



    }
}